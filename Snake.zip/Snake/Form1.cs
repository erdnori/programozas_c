namespace Snake
{
    public partial class Form1 : Form
    {
        int headX = 100;
        int headY = 100;
        int directonX = 1;
        int directonY = 0;
        int stepCounter = 0;
        int snakeLength = 5;

        List<SnakeSegment> snake = new List<SnakeSegment>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            headX += directonX * SnakeSegment.SnakeSegmentSize;
            headY += directonY * SnakeSegment.SnakeSegmentSize;

            var newHead = new SnakeSegment(stepCounter) //var a SnakeSegment helyett
            {  
                Top = headY,
                Left = headX,
            };

            foreach (var segment in snake) { 
                if (segment.Top==headY && segment.Left==headX ) { timer1.Enabled = false; }
            }

            //Farokv�g�s
            if (snake.Count()>snakeLength)
            {
                var farok = snake[0]; // snake.First() is j�
                snake.Remove(farok);
                Controls.Remove(farok);
                // vagy snake.RemoveAt(0); 
            }

            Controls.Add(newHead);
            snake.Add(newHead);
            stepCounter++;

            if(stepCounter%5==0)
            {
                snakeLength++;
            }


        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Up) {
                directonX = 0;
                directonY = -1;
            }
            if(e.KeyCode == Keys.Down) {
                directonX = 0; directonY = 1;
            }
            if(e.KeyCode == Keys.Right) {
                directonX = 1;
                directonY = 0;
            }
            if (e.KeyCode == Keys.Left) {
                directonX = -1;
                directonY = 0;
            }

        }
    }
}