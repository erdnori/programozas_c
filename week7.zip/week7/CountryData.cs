﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week7
{
    public class CountryData //átállítani internal-ból public-ra
    {
        public string Name { get; set; } = string.Empty; //elmúlik a zöld aláhúzás a Name alatt
        public long Population { get; set; }
        public double AreaInSquareKm { get; set; }
    }
}
