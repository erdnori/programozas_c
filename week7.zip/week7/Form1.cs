using CsvHelper;
using System.ComponentModel;
using System.Globalization;

namespace week7
{
    public partial class Form1 : Form
    {
        BindingList<CountryData> countryList = new();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader("countries.csv"); //counties.csv-n�l copy always-ra �ll�tani a properties-n�l
            var csv = new CsvReader(sr, CultureInfo.InvariantCulture); //ha nem j�n be: villanyk�rte -> using, CultureInfo.GetCultureInfo("HU-hu")
            var t�mb = csv.GetRecords<CountryData>();

            foreach (var i in t�mb)
            {
                countryList.Add(i);
            }

            countryDataBindingSource.DataSource = countryList;
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            Form2 f2=new Form2();
            f2.MyCountryData = countryDataBindingSource.Current as CountryData;

            f2.ShowDialog(); 
        }
    }
}